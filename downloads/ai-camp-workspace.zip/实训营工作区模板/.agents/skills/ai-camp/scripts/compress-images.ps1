# Usage: powershell -ExecutionPolicy Bypass -File compress-images.ps1 -Dir "<folder>"
# Shrinks png/jpg in the folder to max 1200px wide, saves as quality-80 jpg, removes the original png.
# Pure ASCII on purpose: Windows PowerShell 5.1 reads BOM-less files as the system codepage.
param([Parameter(Mandatory=$true)][string]$Dir, [int]$MaxWidth = 1200, [int]$Quality = 80)
Add-Type -AssemblyName System.Drawing
$Dir = (Resolve-Path -LiteralPath $Dir).Path
$codec = [System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq 'image/jpeg' }
$ep = New-Object System.Drawing.Imaging.EncoderParameters 1
$ep.Param[0] = New-Object System.Drawing.Imaging.EncoderParameter ([System.Drawing.Imaging.Encoder]::Quality), ([long]$Quality)
Get-ChildItem -LiteralPath $Dir -File | Where-Object { $_.Extension -match '^\.(png|jpg|jpeg)$' } | ForEach-Object {
    $src = [System.Drawing.Image]::FromFile($_.FullName)
    $w = [Math]::Min($MaxWidth, $src.Width); $h = [int]($src.Height * $w / $src.Width)
    $bmp = New-Object System.Drawing.Bitmap $w, $h
    $g = [System.Drawing.Graphics]::FromImage($bmp); $g.InterpolationMode = 'HighQualityBicubic'; $g.DrawImage($src, 0, 0, $w, $h)
    $out = Join-Path $_.DirectoryName ($_.BaseName + '.jpg'); $tmp = $out + '.tmp'
    $bmp.Save($tmp, $codec, $ep); $g.Dispose(); $bmp.Dispose(); $src.Dispose()
    if ($_.Extension -ne '.jpg') { [System.IO.File]::Delete($_.FullName) }
    Move-Item -LiteralPath $tmp -Destination $out -Force
    "{0} -> {1} KB" -f $_.Name, [int]((Get-Item -LiteralPath $out).Length / 1KB)
}
