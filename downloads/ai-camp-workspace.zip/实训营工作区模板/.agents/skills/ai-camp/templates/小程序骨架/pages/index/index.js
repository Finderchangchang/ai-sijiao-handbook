// ===== 第 1 处要改：题目，和网页版 QUESTIONS 完全一致 =====
const QUESTIONS = [
  { id: "q1", type: "choice", title: "【题目1】", options: ["【选项A】", "【选项B】", "【选项C】"] }
];
// ===== 第 2 处要改：结果规则，和网页版 computeResult 完全一致 =====
function computeResult(answers) {
  return { title: "【结果标题】", text: "【结果说明】", rec: "推荐：【档案里的一个产品或服务】", img: "" };
}
// ===== 第 3 处要改：表单链接和电话 =====
const FORM_LINK = "【客户表表单链接】";
const PHONE = "【电话】";
// ===== 以下不用改 =====
Page({
  data: { i: 0, current: QUESTIONS[0], percent: 0, done: false, result: {}, inputValue: "" },
  answers: {},
  choose(e) { this.answers[this.data.current.id] = e.currentTarget.dataset.v; this.next(); },
  onInput(e) { this.setData({ inputValue: e.detail.value }); },
  submitInput() { this.answers[this.data.current.id] = this.data.inputValue.trim(); this.setData({ inputValue: "" }); this.next(); },
  next() {
    const i = this.data.i + 1;
    if (i < QUESTIONS.length) this.setData({ i, current: QUESTIONS[i], percent: i / QUESTIONS.length * 100 });
    else this.setData({ done: true, result: computeResult(this.answers), percent: 100 });
  },
  copyLink() { wx.setClipboardData({ data: FORM_LINK, success: () => wx.showToast({ title: "已复制，粘贴到微信打开", icon: "none" }) }); },
  callPhone() { wx.makePhoneCall({ phoneNumber: PHONE }); },
  restart() { this.answers = {}; this.setData({ i: 0, current: QUESTIONS[0], percent: 0, done: false, result: {} }); }
});